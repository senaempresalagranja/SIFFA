<?php 

echo "string"; ?>